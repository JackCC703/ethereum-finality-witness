//! Historical, pinned-snapshot Verify -> Apply LEZ v0.4 placement demonstration.
//! The public instance stores only authenticated summary/commitment, never keys.
use finality_witness_core::incremental::{PINNED_SNAPSHOT_SHA256, verify_pinned_update};
use lee_core::{
    account::{AccountId, Actor},
    program::{ReceiveInput, Response},
};
use serde_json::{Value, json};
use std::str::FromStr;
const INITIAL_SLOT: u64 = 7104096;
fn decode(bytes: &[u8]) -> Value {
    serde_json::from_slice(bytes).expect("FW_JSON")
}
fn number(value: &Value) -> u64 {
    value.as_u64().expect("FW_NUMBER")
}

/// Messages are Borsh Vec<u8> containing JSON. `apply` is internal-only.
pub fn handle(input: &ReceiveInput, message: Vec<u8>) -> Response {
    let m = decode(&message);
    match m["op"].as_str().expect("FW_OPERATION") {
        "initialize" => {
            assert!(input.pre_state.is_empty(), "FW_ALREADY_INITIALIZED");
            // No checkpoint, root, slot, or store argument is accepted from caller.
            let initial = json!({"schema":"fw-public-instance-v1","chain_id":1,
                "store_commitment":PINNED_SNAPSHOT_SHA256,"finalized_slot":INITIAL_SLOT,
                "execution_block":17917816u64,"updates_applied":0});
            Response::set_state(serde_json::to_vec(&initial).unwrap())
        }
        "verify" => {
            let target = AccountId::from_str(m["public_instance"].as_str().expect("FW_INSTANCE"))
                .expect("FW_INSTANCE");
            let result =
                verify_pinned_update(&m["witness"]).unwrap_or_else(|e| panic!("FW_VERIFY:{e}"));
            assert_eq!(result["chain_id"], 1, "FW_CHAIN");
            let apply = json!({"op":"apply","verified":result});
            Response::keep_state().send_sync(
                Actor::new(target, input.receiver.program_account_id),
                &serde_json::to_vec(&apply).unwrap(),
            )
        }
        "apply" => {
            assert!(input.from_own_program(), "FW_APPLY_AUTH");
            assert!(!input.pre_state.is_empty(), "FW_NOT_INITIALIZED");
            let old = decode(&input.pre_state);
            assert_eq!(old["schema"], "fw-public-instance-v1", "FW_INSTANCE_SCHEMA");
            let v = &m["verified"];
            assert_eq!(v["chain_id"], old["chain_id"], "FW_CHAIN");
            assert_eq!(
                v["previous_store_commitment"], old["store_commitment"],
                "FW_STALE_STORE"
            );
            assert!(
                number(&v["finalized_slot"]) > number(&old["finalized_slot"]),
                "FW_SLOT_ORDER"
            );
            assert_eq!(
                v["new_store_commitment"]
                    .as_str()
                    .expect("FW_COMMITMENT")
                    .len(),
                64,
                "FW_COMMITMENT"
            );
            let count = number(&old["updates_applied"])
                .checked_add(1)
                .expect("FW_OVERFLOW");
            let updated = json!({"schema":"fw-public-instance-v1","chain_id":1,
                "store_commitment":v["new_store_commitment"],"finalized_slot":v["finalized_slot"],
                "execution_block":v["execution_block"],"execution_block_hash":v["execution_block_hash"],
                "finalized_beacon_root":v["finalized_beacon_root"],"state_root":v["state_root"],
                "updates_applied":count});
            Response::set_state(serde_json::to_vec(&updated).unwrap())
        }
        _ => panic!("FW_UNKNOWN_OPERATION"),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use lee_core::account::ActorState;
    fn actor(id: u8, program: u8) -> Actor {
        Actor::new(AccountId::new([id; 32]), AccountId::new([program; 32]))
    }
    fn input(from: Option<Actor>, state: &[u8]) -> ReceiveInput {
        ReceiveInput {
            receiver: actor(2, 3),
            from,
            is_authorized: false,
            pre_state: ActorState::from(state.to_vec()),
            message: vec![],
        }
    }
    fn msg(v: Value) -> Vec<u8> {
        serde_json::to_vec(&v).unwrap()
    }
    fn initialized() -> Vec<u8> {
        handle(&input(None, &[]), msg(json!({"op":"initialize"})))
            .post_state
            .unwrap()
            .to_vec()
    }
    fn witness() -> Value {
        serde_json::from_str(include_str!("../../incremental-input.json")).unwrap()
    }
    fn applied_message() -> Vec<u8> {
        let v = json!({"op":"verify","public_instance":AccountId::new([2;32]).to_string(),"witness":witness()});
        let r = handle(&input(None, &[]), msg(v));
        assert!(r.post_state.is_none());
        assert_eq!(r.sync_messages.len(), 1);
        borsh::from_slice(&r.sync_messages[0].message).unwrap()
    }
    fn refuses(i: ReceiveInput, m: Vec<u8>) {
        let before = i.pre_state.clone();
        assert!(std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| handle(&i, m))).is_err());
        assert_eq!(i.pre_state, before);
    }
    #[test]
    fn valid_private_style_verify_to_own_program_apply() {
        let state = initialized();
        let updated = handle(&input(Some(actor(5, 3)), &state), applied_message())
            .post_state
            .unwrap();
        let j = decode(&updated);
        assert_eq!(j["updates_applied"], 1);
        assert_eq!(j["finalized_slot"], 7109344);
        assert_eq!(j["execution_block"], 17923026);
        assert!(updated.len() < 1024);
    }
    #[test]
    fn direct_apply_refused() {
        refuses(input(None, &initialized()), applied_message());
    }
    #[test]
    fn other_program_apply_refused() {
        refuses(input(Some(actor(5, 9)), &initialized()), applied_message());
    }
    #[test]
    fn duplicate_apply_refused() {
        let m = applied_message();
        let updated = handle(&input(Some(actor(5, 3)), &initialized()), m.clone())
            .post_state
            .unwrap();
        refuses(input(Some(actor(5, 3)), &updated), m);
    }
    #[test]
    fn repeated_initialize_refused() {
        refuses(input(None, &initialized()), msg(json!({"op":"initialize"})));
    }
    #[test]
    fn fake_snapshot_refused() {
        let mut w = witness();
        w["store"]["chain_id"] = json!(2);
        refuses(
            input(None, &[]),
            msg(
                json!({"op":"verify","public_instance":AccountId::new([2;32]).to_string(),"witness":w}),
            ),
        );
    }
    #[test]
    fn invalid_signature_refused() {
        let mut w = witness();
        w["update"]["data"]["sync_aggregate"]["sync_committee_signature"] =
            json!("0x".to_owned() + &"00".repeat(96));
        refuses(
            input(None, &[]),
            msg(
                json!({"op":"verify","public_instance":AccountId::new([2;32]).to_string(),"witness":w}),
            ),
        );
    }
}
