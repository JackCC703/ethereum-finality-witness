//! One-update historical placement demo. The imported snapshot is an explicit,
//! pinned trust input, reproducibly derived from bootstrap + six verified updates.
//! Public LEZ state must authenticate this commitment; caller-supplied roots are
//! never accepted merely because a JSON field says they were verified.
use crate::{
    beacon, branch, committee, h, header, need, num, rb, signature, state, Root, CP, GENESIS, R,
};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
pub const PINNED_SNAPSHOT_SHA256: &str =
    "76084610a9e4dfe1aea101c87bf9734b3d7a5a423d0d63f222c2b75ecfdc3aac";

pub fn commitment(store: &Value) -> R<String> {
    let encoded = serde_json::to_vec(store).map_err(|_| "STORE_ENCODING")?;
    let mut hash = Sha256::new();
    hash.update(b"finality-witness/verified-store/v1\0");
    hash.update(encoded);
    Ok(hex::encode(hash.finalize()))
}
fn bootstrap(input: &Value) -> R<Value> {
    let b = &input["bootstrap"]["data"];
    header(&b["header"])?;
    need(
        hex::encode(beacon(&b["header"]["beacon"])?) == CP,
        "CHECKPOINT_MISMATCH",
    )?;
    branch(
        committee(&b["current_sync_committee"])?,
        &b["current_sync_committee_branch"],
        54,
        rb(&b["header"]["beacon"]["state_root"])?,
        "BOOTSTRAP_COMMITTEE",
    )?;
    Ok(
        json!({"schema":"fw-historical-capella-store-v1","chain_id":1,"checkpoint":CP,
        "finalized_header":b["header"],"current_sync_committee":b["current_sync_committee"],"next_sync_committee":null}),
    )
}
fn advance(store: &Value, wrapped: &Value) -> R<(Value, usize)> {
    need(
        store["chain_id"] == 1
            && store["checkpoint"] == CP
            && store["schema"] == "fw-historical-capella-store-v1",
        "STORE_PROFILE",
    )?;
    let u = &wrapped["data"];
    let a = &u["attested_header"];
    let f = &u["finalized_header"];
    let ss = num(&u["signature_slot"])?;
    let at = num(&a["beacon"]["slot"])?;
    let fs = num(&f["beacon"]["slot"])?;
    let old = num(&store["finalized_header"]["beacon"]["slot"])?;
    let period = old / 8192;
    let next = &store["next_sync_committee"];
    need(7109432 >= ss && ss > at && at >= fs, "SLOT_ORDER")?;
    need(
        fs > old || next.is_null() && !u["next_sync_committee"].is_null(),
        "STALE_UPDATE",
    )?;
    need(
        ss / 8192 == period || ss / 8192 == period + 1,
        "SIGNATURE_PERIOD",
    )?;
    let c = if ss / 8192 == period {
        &store["current_sync_committee"]
    } else {
        need(!next.is_null(), "UNKNOWN_COMMITTEE")?;
        next
    };
    header(a)?;
    header(f)?;
    branch(
        beacon(&f["beacon"])?,
        &u["finality_branch"],
        105,
        rb(&a["beacon"]["state_root"])?,
        "FINALITY_BRANCH",
    )?;
    if !u["next_sync_committee"].is_null() {
        branch(
            committee(&u["next_sync_committee"])?,
            &u["next_sync_committee_branch"],
            55,
            rb(&a["beacon"]["state_root"])?,
            "NEXT_COMMITTEE",
        )?;
    }
    let mut version = [0; 32];
    version[..4].copy_from_slice(&[3, 0, 0, 0]);
    let genesis: Root = hex::decode(GENESIS).unwrap().try_into().unwrap();
    let fr = h(&version, &genesis);
    let mut domain = [0; 32];
    domain[..4].copy_from_slice(&[7, 0, 0, 0]);
    domain[4..].copy_from_slice(&fr[..28]);
    let signers = signature(c, &u["sync_aggregate"], h(&beacon(&a["beacon"])?, &domain))?;
    let mut updated = store.clone();
    if fs / 8192 == period + 1 {
        need(!next.is_null(), "MISSING_HANDOFF")?;
        updated["current_sync_committee"] = next.clone();
        updated["next_sync_committee"] = u["next_sync_committee"].clone();
    } else {
        need(fs / 8192 == period, "FINALITY_PERIOD")?;
        if next.is_null() && !u["next_sync_committee"].is_null() {
            updated["next_sync_committee"] = u["next_sync_committee"].clone();
        }
    }
    if fs > old {
        updated["finalized_header"] = f.clone();
    }
    Ok((updated, signers))
}

/// Deterministically rebuild the demo seed from the original trusted checkpoint.
/// This does real native consensus verification; it is not itself a zk proof.
pub fn historical_snapshot(input: &Value) -> R<Value> {
    let mut store = bootstrap(input)?;
    let updates = input["updates"].as_array().ok_or("UPDATES")?;
    need(updates.len() == 6, "SNAPSHOT_HISTORY_LENGTH")?;
    for update in updates {
        store = advance(&store, update)?.0;
    }
    Ok(store)
}

/// Verify one update against the pinned imported snapshot. This deliberately
/// supports a fixed historical demonstration, not arbitrary caller-owned stores.
pub fn verify_pinned_update(input: &Value) -> R<Value> {
    let store = &input["store"];
    let previous = commitment(store)?;
    need(previous == PINNED_SNAPSHOT_SHA256, "UNAUTHENTICATED_STORE")?;
    let (updated, signers) = advance(store, &input["update"])?;
    let fin = &updated["finalized_header"];
    let mut result = json!({"chain_id":1,"checkpoint":CP,"previous_store_commitment":previous,
        "new_store_commitment":commitment(&updated)?,"finalized_slot":num(&fin["beacon"]["slot"])? ,
        "finalized_beacon_root":hex::encode(beacon(&fin["beacon"])?) ,
        "execution_block":num(&fin["execution"]["block_number"])? ,
        "execution_block_hash":fin["execution"]["block_hash"],"state_root":fin["execution"]["state_root"],
        "signers":signers,"trust_boundary":"fixed historical snapshot commitment, not a fresh checkpoint or a verified prior zk receipt"});
    if !input["state_proof"].is_null() {
        result["state_witness"] =
            state(rb(&fin["execution"]["state_root"])?, &input["state_proof"])?;
    }
    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;
    fn full() -> Value {
        serde_json::from_str(include_str!("../../input.json")).unwrap()
    }
    fn input() -> Value {
        let f = full();
        json!({"store":historical_snapshot(&f).unwrap(),"update":f["finality"],"state_proof":f["state_proof"]})
    }
    #[test]
    fn snapshot_is_reproducibly_pinned() {
        assert_eq!(
            commitment(&historical_snapshot(&full()).unwrap()).unwrap(),
            PINNED_SNAPSHOT_SHA256
        );
    }
    #[test]
    fn final_update_matches_full_replay() {
        let i = input();
        let r = verify_pinned_update(&i).unwrap();
        let f = crate::verify(&full()).unwrap();
        assert_eq!(r["execution_block"], f["execution_block"]);
        assert_eq!(r["state_witness"], f["state_witness"]);
    }
    #[test]
    fn rejects_fake_snapshot_root() {
        let mut i = input();
        i["store"]["finalized_header"]["execution"]["state_root"] =
            json!("0x".to_owned() + &"11".repeat(32));
        assert_eq!(
            verify_pinned_update(&i).unwrap_err(),
            "UNAUTHENTICATED_STORE"
        );
    }
    #[test]
    fn rejects_tampered_signature_without_mutation() {
        let mut i = input();
        i["update"]["data"]["sync_aggregate"]["sync_committee_signature"] =
            json!("0x".to_owned() + &"00".repeat(96));
        let before = i.clone();
        assert!(verify_pinned_update(&i).is_err());
        assert_eq!(i, before);
    }
    #[test]
    fn rejects_replayed_old_update() {
        let mut i = input();
        i["update"] = full()["updates"][5].clone();
        assert_eq!(verify_pinned_update(&i).unwrap_err(), "STALE_UPDATE");
    }
}
